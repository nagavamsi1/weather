document.getElementById("getWeatherBtn").addEventListener("click", function () {
    const location = document.getElementById("location").value;
    if (location === "") {
        alert("Please enter a location");
        return;
    }

    fetch(`http://localhost:8080/weather?city=${location}`)
        .then(response => response.json())
        .then(data => {
            console.log(data);  // Log the data to inspect its structure
            document.getElementById("weatherData").innerHTML = `
            <h2>${data.city}</h2>
            <p>Temperature: ${data.temperature}°C</p>
            <p>Weather: ${data.description}</p>
        `;
        })
        .catch(error => {
            console.error("Error fetching weather data:", error);
            document.getElementById("weatherData").innerHTML = "Error fetching weather data";
        });
});

