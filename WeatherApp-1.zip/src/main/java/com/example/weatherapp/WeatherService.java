package com.example.weatherapp;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.HashMap;
import java.util.Map;
import java.util.List;

@Service
public class WeatherService {

    private final String apiKey = "9fc0b0dc734c9944305e47d4c3cf0e69"; // Replace with OpenWeatherMap API key
    private final String weatherUrl = "http://api.openweathermap.org/data/2.5/weather";

    public Map<String, Object> getWeatherData(String city) {
        RestTemplate restTemplate = new RestTemplate();

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(weatherUrl)
                .queryParam("q", city)
                .queryParam("appid", apiKey)
                .queryParam("units", "metric");

        Map<String, Object> response = restTemplate.getForObject(uriBuilder.toUriString(), HashMap.class);

        Map<String, Object> result = new HashMap<>();
        result.put("city", response.get("name"));
        Map<String, Object> main = (Map<String, Object>) response.get("main");
        result.put("temperature", main.get("temp"));
        Map<String, Object> weather = ((List<Map<String, Object>>) response.get("weather")).get(0);
        result.put("description", weather.get("description"));

        return result;
    }
}
